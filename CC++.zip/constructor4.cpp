#include <iostream>
using namespace std;

class Line
{   int size;
    Line()
    {
        size = 30;
        cout << "size = " << size << endl;
    }

    public:
        static Line fun()
        {
            static Line *s;
            if (s == NULL)
            {
                Line s1;
                s = &s1;
            }
            else{
                cout << "Already Present" << endl;
            }
            cout << "Hello I'm inside Class" << endl;
            cout << s->size << endl;
            return *s;
        }
        void area()
        {
            cout << "AREAAAAAA!!!!" << size << endl;
        }
};
int main()
{
    Line str =  Line::fun();
    Line str1 =  Line::fun();
    str.area();
    str.fun();
    str.area();
    str.fun();
    return 0;
}