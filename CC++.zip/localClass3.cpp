void f()
{
    class Local{
        int f();
        int g(){return 0;}
        // static int a;
        int b;
    };
}

int main()
{}