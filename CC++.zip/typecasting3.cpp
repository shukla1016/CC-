#include <iostream>
using namespace std;

struct x
{
    int x;
    double y;
    char c;
    bool b;
};

int main()
{
    x f;
    f.x = 10;
    f.y = 1453.50;
    f.c = 'A';
    f.b = true;
    x b;
    int *p = reinterpret_cast<int*>(&f);
    (*p)++;
    cout << sizeof(f) << endl;
    cout << ++(*p) << endl;
}