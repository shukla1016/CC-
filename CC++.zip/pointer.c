#include<stdio.h>
void main()
{
    int *p,a=10;
    p=&a;
    printf("Value of Pointer = %p\n",p);
    printf("Content of Pointer = %d\n",*p);
    printf("Address of Variable = %p\n",&a);
    printf("Value of Variable = %d\n",a);
    printf("Address of Pointer%p\n",&p);
    a=12520;
    printf("Value of Pointer = %p\n",p);
    printf("Content of Pointer = %d\n",*p);
    printf("Address of Variable = %p\n",&a);
    printf("Value of Variable = %d\n",a);
    printf("Address of Pointer%p\n",&p);
    *p=120;
    printf("Value of Pointer = %p\n",p);
    printf("Content of Pointer = %d\n",*p);
    printf("Address of Variable = %p\n",&a);
    printf("Value of Variable = %d\n",a);
    printf("Address of Pointer%p\n",&p);
}