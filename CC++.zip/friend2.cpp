#include <iostream>
using namespace std;


class B;
class A {
    private : int meter;
    friend int add(A, B);
    public :
        A() : meter(10){}
};

class B {
    private : int meter;
    friend int add(A, B);
    public :
        B() : meter(12){}
};

int add(A a, B b)
{
    int a1 = a.meter + b.meter;
    return a1;
}

int main()
{
    A a;
    B b;
    int a1 = add(a,b);
    cout << a1 << endl;
    return 0;
}