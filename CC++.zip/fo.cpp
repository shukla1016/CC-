#include <iostream>
using namespace std;

int sum(int a, int b)
{
    int c = a+b;
    return c;    
}
double sum(double a, double b)
{
    double c = a+b;
    return c;    
}
 
int main ()
{
    int res = sum(4,5);
    double res1 = sum(2.1,3.6);
    cout << res << endl << res1 << endl;
    return 0;
}
