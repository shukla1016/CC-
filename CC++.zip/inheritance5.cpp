#include <iostream>
using namespace std;

class World{
    public:
        World()
        {
            cout << "This is World." << endl; 
        }
};

class Continent : public World{
    public:
        Continent()
        {
            cout << "This is the Continent." << endl;
        }
};

class Country : public Continent{
    public:
        Country()
        {
            cout << "This is the Country." << endl;
        }
};

class India : public Country{
    public:
        India()
        {
            cout << "This is India." << endl;
        }
};

int main()
{
    India india;
}