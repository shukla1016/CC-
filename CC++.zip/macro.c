#include<stdio.h>
#define AREA_CIR
// #define AREA_TRI
#if !defined (AREA_CIR) && !defined(AREA_TRI)
    #warning "Nothing is there"
#endif

void main()
{
    #ifdef AREA_CIR
        printf("Circle is here");
    #endif
    #ifdef AREA_TRI
        printf("Triangle is here");
    #endif
}