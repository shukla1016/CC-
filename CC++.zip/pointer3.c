#include<stdio.h>
#include<stdlib.h>
void main ()
{
    int *a,*b;
    int x = 10;
    int y = 20;
    a=&x;
    b=&y;
    printf("Before swapping : a= %d b = %d\n",*a,*b);
    *a = *a+*b;
    *b = *a-*b;
    *a = *a-*b;
    printf("After swapping : a= %d b = %d\n",*a,*b);
}