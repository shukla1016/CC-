#include<iostream>
#include<iterator>
#include<list>
using namespace std;

void showTheContent(list < int > lst)
{
    list <int> :: iterator it;
    for(it = lst.begin();it!=lst.end();++it)
        cout << *it << " ";
    cout << endl;
}

int main ()
{
    list <int> list1, list2;
    for(int i = 0; i<=10;++i)
    {
        list1.push_back(i);
        list2.push_front(i+5);
    }
    cout << "List 1 = ";
    showTheContent(list1);
    cout << "List 2 = ";
    showTheContent(list2);
    list2.sort();
    cout << "Sorted List 2 = ";
    showTheContent(list2);
    int times = 5;
    while(times --)
    {
        list1.pop_front();
    }

    times = 5;
    while(times --)
    {
        list2.pop_front();
    }

    cout << "List 1 = ";
    showTheContent(list1);
    cout << "List 2 = ";
    showTheContent(list2);

    cout << list1.front() << " is at front of list 1." << endl;
    cout << list2.front() << " is at front of list 2." << endl;

    list1.insert(list1.begin(),5,10);
    cout << "List 1 = ";
    showTheContent(list1);

    list2.insert(list2.begin(),2,110);
    cout << "List 2 = ";
    showTheContent(list2);

    list1.remove(10);
    cout << "After removal of 10 = ";
    showTheContent(list1);

    list1.reverse();
    cout << "Reverse of List 1 = ";
    showTheContent(list1);

    cout << "Size of list1 = " << list1.size();

    cout << "Size of list2 = " << list2.size();

    list1.erase(list1.begin());
    cout << "After erasing from list 1 = ";
    showTheContent(list1);

    list2.erase(list2.begin());
    cout << "After erasing from list 2 = ";
    showTheContent(list2);

    return 0;
}