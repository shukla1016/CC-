#include <iostream>
using namespace std;

class Base{
    public:
    int x,y;
        void data()
        {
            cout << "Enter x and y." << endl;
            cin >> x >> y;
        }
};

class Derived1 : public Base{
    public:
    void add()
    {
        cout << "The sum is " << (x+y) << endl;
    }
};
class Derived2 : public Derived1{
    public:
    void mul()
    {
        cout << "The product is " << (x*y) << endl;
    }
};

int main()
{
    Derived2 x,y;
    x.data();
    x.add();
    y.data();
    y.mul();
}