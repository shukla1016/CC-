#include<stdio.h>
int main(){
    FILE *fp;
    char buff[355];
    char buff1[255];
    fp = fopen("/home/parth/cprog/test.txt","r");
    fgets(buff,255,(FILE*)fp);
    printf("1 : %s\n",buff);
    fgets(buff,255,(FILE*)fp);
    printf("2 : %s\n",buff);
    // fflush(stdout);
    fgets(buff1,255,(FILE*)fp);
    printf("3 : %s\n",buff1);
    fclose(fp);
    return 0;
}