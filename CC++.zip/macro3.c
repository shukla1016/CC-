#include<stdio.h>
#define MIN(a,b) ((a) < (b)?(a):(b))
void main()
{
    printf("Minimum between 10 and 20 is %d",MIN(10,20));
} 