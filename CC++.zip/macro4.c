#include<stdio.h>
#define MAX(a,b) ((a) > (b)?(a):(b))
void main()
{
    printf("Maximum between 10 and 20 is %d",MAX(10,20));
} 