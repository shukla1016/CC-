#include<stdio.h>
int main(){
    FILE *fp;
    fp = fopen("/home/parth/cprog/test.txt","a+");
    fprintf(fp,"This is fprint\n");
    fputs("I love Cricket.",fp);
    fclose(fp);
    return 0;
}