#include<iostream>
#include<iterator>
#include<list>
using namespace std;

void print(list < int > lst)
{
    list <int> :: iterator it;
    for(it = lst.begin();it!=lst.end();++it)
        cout << *it << " ";
    cout << endl;
}

int main ()
{
    list <int> list1, list2;
    for(int i = 0; i<5;++i)
    {
        list1.push_back(i);
        list2.push_front(i+5);
    }
    cout << "List 1 = ";
    print(list1);
    cout << "List 2 = ";
    print(list2);
    cout << "List 1 front = " << list1.front() << endl;
    cout << "List 2 front = " << list2.front() << endl;
    cout << "List 1 back = " << list1.back() << endl;
    cout << "List 2 back = " << list2.back() << endl;
    cout << "List 1 pop front = ";
    list1.pop_front();
    print(list1);
    list2.pop_front();
    cout << "List 2 pop front = ";
    print(list2);
    cout << "List 1 pop back = ";
    list1.pop_back();
    print(list1);
    list2.pop_back();
    cout << "List 2 pop back = ";
    print(list2);
    cout << "List 1 reverse = ";
    list1.reverse();
    print(list1);
    list2.reverse();
    cout << "List 2 reverse = ";
    print(list2);
    return 0;
}