#include<stdio.h>
#include<stdlib.h>

struct Node{
    int data;
    int priority;
    struct Node *next;
}*front=NULL,*rear=NULL;
void insertQueue(int data, int priority)
{
    struct Node *temp = (struct Node*)malloc(sizeof(struct Node));
    if(temp == NULL)
    {
    printf("Memory Not Available");
    return;
    }
    temp->data = data;
    temp->next = NULL;
    temp->priority = priority;
    if (front == NULL || front->priority>temp->priority)
    {
        temp->next = front;
        front = temp;
    }
    else
    {
    struct Node *p = front;
    while(p->next != NULL && p->next->priority<=temp->priority)
    {
        p=p->next;
    }
    temp->next = p->next;
    p->next = temp;
    }
    rear = temp;
}

void deleteQueue()
{
    struct Node *temp = front;
    front = front->next;
    free(temp);
}

void isEmpty()
{
    if(front == NULL)
    {
        printf("Empty!");
    }
    else{
        printf("Not Empty!");
    }
}

void peek()
{
    if(front == NULL)
    {
        printf("No-one is here !");
    }
    else{
        printf("%d",front->data);
    }
}

void print()
{
    struct Node *temp = front;
    while(temp != NULL)
    {
        if(temp->next==NULL)
        printf("%d",temp->data);
        else
        printf("%d-",temp->data);
        temp=temp->next;
    }
}

void main()
{
    isEmpty();
    printf("\n");
    peek();
    printf("\n");
    insertQueue(20,4);
    insertQueue(25,2);
    insertQueue(2,3);
    insertQueue(29,5);
    insertQueue(30,1);
    print();
    printf("\n");
    isEmpty();
    printf("\n");
    peek();
    deleteQueue();
    printf("\n");
    print();
}