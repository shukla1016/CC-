#include <iostream>
using namespace std;

class Line
{   int size;
    public:
        
        Line()
        {
            size = 30;
            cout << "size = " << size << endl;

        }
};
int main()
{
    Line s1;
}