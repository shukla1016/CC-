#include <stdio.h>
#include <stdlib.h>

struct node {
    int data;
    struct node* lchild;
    struct node* rchild;
};// *root = NULL;
void inorder(struct node* root) {
    if (root == NULL) return;
    inorder(root->lchild);
    printf("%d ->", root->data);
    inorder(root->rchild);
}
void preorder(struct node* root) {
    if (root == NULL) return;
    printf("%d ->", root->data);
    preorder(root->lchild);
    preorder(root->rchild);
}
void postorder(struct node* root) {
    if (root == NULL) return;
    postorder(root->lchild);
    postorder(root->rchild);
    printf("%d ->", root->data);
}
struct node* newNode(int value) {
    struct node* newNode = malloc(sizeof(struct node));
    newNode->data = value;
    newNode->lchild = NULL;
    newNode->rchild = NULL;
    return newNode;
}
struct node *deleteNode(struct node *root, int data)
{
    if(root==NULL)return root;
    if(data < root->data)
    root->lchild = deleteNode(root->lchild,data);
    else if (data > root->data)
    root->rchild = deleteNode(root->rchild,data);
    else{
        if(root->lchild==NULL)
        {
            struct node *temp = root->rchild;
            free(root);
            return temp;
        }
        else if(root->rchild==NULL)
        {
            struct node *temp = root->lchild;
            free(root);
            return temp;
        }
    }
}
struct node* bst(struct node *root, int data) {
    if (root == NULL) 
        return newNode(data);
    if (data < root->data)
        root->lchild = bst(root->lchild, data);
    else
        root->rchild = bst(root->rchild, data);
    return root;
}
struct node* insertLeft(struct node* root, int value) {
    root->lchild = newNode(value);
    return root->lchild;
}
struct node* insertRight(struct node* root, int value) {
    root->rchild = newNode(value);
    return root->rchild;
}
int main() {
    struct node *root = NULL;
//   insertLeft(root, 85);
//   insertRight(root, 63);
//   insertLeft(root->lchild, 42);
//   insertRight(root->rchild,10);
    root = bst(root,51);
    bst(root,15);
    bst(root,19);
    bst(root,81);
    bst(root,91);
    bst(root,10);
    printf("Inorder traversal \n");
    inorder(root);
    deleteNode(root,15);
    printf("\nPreorder traversal \n");
    preorder(root);
    printf("\nPostorder traversal \n");
    postorder(root);
    printf("\n");
}