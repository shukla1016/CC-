#include<stdio.h>
int addition();
int addition1();
int area (int side)
{
    return (side*side);
}
void main()
{
    int result = 0;
    int (*ptr)();
    ptr = &addition;
    result = (*ptr)();
    printf("The sum is %d",result);
    ptr = &addition1;
    result = (*ptr)();
    printf("The sum is %d",result);
    ptr = &area;
    result = (*ptr)(10);
    printf("Square of 5 is : %d",result);
}
int addition(){
    int a,b;
    printf("Enter Two Numbers.");
    scanf("%d %d",&a,&b);
    return (a+b);
}
int addition1(){
    int a,b,c;
    printf("Enter Three Numbers.");
    scanf("%d %d %d",&a,&b,&c);
    return (a+b+c);
}