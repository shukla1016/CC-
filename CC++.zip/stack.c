#include<stdio.h>
#include<stdlib.h>

struct Node{
    int data;
    struct Node *next;
}*top=NULL;
void push(int data)
{
    struct Node *temp= (struct Node*)malloc(sizeof(struct Node));
    if(temp == NULL)
    {
        printf("Memory Not Available");
        return;
    }
    temp->data = data;
    temp->next = top;
    top = temp;
}

void pop()
{
    if(top == NULL)
    {
        printf("Stack is Empty!");
        return;
    }
    struct Node *temp = top;
    top = top->next;
    free(temp);
}

void isEmpty()
{
    if(top == NULL)
    {
        printf("Empty!");
    }
    else{
        printf("Not Empty!");
    }
}

void peek()
{
    if(top == NULL)
    {
        printf("No-one is here !");
    }
    else{
        printf("%d",top->data);
    }
}

void print()
{
    struct Node *temp = top;
    while(temp != NULL)
    {
        printf("%d\n",temp->data);
        temp=temp->next;
    }
}

void main()
{
    isEmpty();
    printf("\n");
    peek();
    printf("\n");
    pop();
    printf("\n");
    push(20);
    push(25);
    push(2);
    push(29);
    push(30);
    print();
    printf("\n");
    isEmpty();
    printf("\n");
    peek();
    pop();
    printf("\n====\n");
    print();
}