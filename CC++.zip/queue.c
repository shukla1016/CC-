#include<stdio.h>
#include<stdlib.h>

struct Node{
    int data;
    struct Node *next;
}*front=NULL,*rear=NULL;
void insertQueue(int data)
{
    struct Node *temp= (struct Node*)malloc(sizeof(struct Node));
    if(temp == NULL)
    printf("Memory Not Available");
    temp->data = data;
    temp->next = NULL;
    if (front == NULL)
    {
        front = temp;
    }
    else
    {
        rear->next=temp;
    }
    rear = temp;
}

void deleteQueue()
{
    struct Node *temp = front;
    front = front->next;
    free(temp);
}

void isEmpty()
{
    if(front == NULL)
    {
        printf("Empty!");
    }
    else{
        printf("Not Empty!");
    }
}

void peek()
{
    if(front == NULL)
    {
        printf("No-one is here !");
    }
    else{
        printf("%d",front->data);
    }
}

void print()
{
    struct Node *temp = front;
    while(temp != NULL)
    {
        if(temp->next==NULL)
        printf("%d",temp->data);
        else
        printf("%d-",temp->data);
        temp=temp->next;
    }
}

void main()
{
    isEmpty();
    printf("\n");
    peek();
    printf("\n");
    insertQueue(20);
    insertQueue(25);
    insertQueue(2);
    insertQueue(29);
    insertQueue(30);
    print();
    printf("\n");
    isEmpty();
    printf("\n");
    peek();
    deleteQueue();
    printf("\n");
    print();
}