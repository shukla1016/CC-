#include<stdio.h>
#include<string.h>
void main()
{
    char ch[11] = {'a','b','c','d','e','f','g','h','i','j','k'};
    char ch1[11] = "abcdefghijk";
    printf("%s\n",ch);
    printf("%s",ch1);
}