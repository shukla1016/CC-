#include <iostream>
using namespace std;

template <class T, class U>
bool areEqual(T a, U b)
{
    return(a==b);
}
 
int main ()
{
    if(areEqual(10,10.0))
    {
        cout << "x and y are equal \n";
    }
    else
    {
        cout << "x and y are not equal \n";
    }
    return 0;
}