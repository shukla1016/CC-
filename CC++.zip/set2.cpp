#include<iostream>
#include<set>
using namespace std;
int main()
{
    set <int> s = {10,12,15,6};
    set<int> ::iterator it;
    cout << "First element is : " << *(s.begin());
    cout << "\nlast element is : " << *--(s.end())<<endl;
    for(auto kt = s.begin(); kt != s.end(); kt ++)
        cout << ' ' << *kt;
    cout << endl; 

    if(s.empty())
    cout << "Empty";
    else
    cout << "Not Empty";
    cout << "\n Size of the set :" << s.size();
    cout << "\n Max Size: " << s.max_size();
    s.erase(s.begin());
    s.erase(12);
    cout << "\n After removing first and 12";
    for(auto kt = s.begin(); kt != s.end(); kt ++)
        cout << ' ' << *kt;
    cout << endl;
    s.insert(5);
    cout << "\n After adding 5 ";
    for(auto kt = s.begin(); kt != s.end(); kt ++)
        cout << ' ' << *kt;
    cout << endl;
    if(s.count(15)==1)
    {
        cout<<endl<<"15 is present in the set";
    }
    else
    {
        cout << endl << "15 is not present";
    }
    s.clear();
    if(s.empty())
    cout << "\nSet is Empty.";
    else
    cout << "\nSet is not Empty.";
    return 0;
}