#include<stdio.h>
#include<stdlib.h>
void main ()
{
    int *p = (int*)malloc(sizeof(int));
    *p = 100;
    free(p);
    printf("The value of p is = %p",p);
    p = NULL;
    printf("The value of p is = %p",p);
}