#include<iostream>
using namespace std;

void display(int x, int y = 10)
{
    cout << "INT------" << x << " --- " << y << endl;
}

// void display(int)
//  {
//      cout << "FLOAT" << endl;
//  }

int main()
{
    int x = 10,y;
    display(x);
}