#include<iostream>
#include<bits/stdc++.h>
using namespace std;
class Parth
{  public:
    int x;
    int y;
    string z;
};
int main()
{  cout<<"enter x and y";
Parth k;



cin>>k.x>>k.y;
cout<<"enter z";
cin>>ws;

getline(cin,k.z);
cout<<k.x<<" "<<k.y<<" ";




cout<<k.z<<" ";

    return 0;
}