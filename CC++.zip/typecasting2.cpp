#include <iostream>
using namespace std;
typedef unsigned char BYTE;

int main()
{
    int i = 65;
    float f = 2.5;
    char ch = static_cast<char>(i);
    cout << ch << i << endl;
    double db1 = static_cast<double>(f);
    i = static_cast<BYTE>(ch);
    cout << ch << i << f << db1 << endl;
    return 0;
}