#include<stdio.h>
union test
{
    int worker_no;
    float salary;
}j;
void main()
{
    j.salary=1500;
    printf("Salary = %0.1f\n",j.salary);
    j.worker_no = 120;
    printf("Worker Number = %d\n",j.worker_no);
    printf("Salary = %0.1f\n",j.salary);
}