#include <iostream>
using namespace std;

class Line
{   int size;
    public:
        Line(){}
        Line(int i, int j)
        {
            size = i*j;
            cout << i << " * " << j << " = " << size << endl;

        }
};
int main()
{
    Line *s1 = new Line[15];
    int i;
    for(i=0;i<15;i++)
    {
        s1[i] = Line(i,i+1);
    }
}