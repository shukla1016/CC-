#include <iostream>
using namespace std;

class ABC{
    public:
    int n;
    ABC(): n(10){}
};

int main()
{
    ABC a;
    cout << a.n << endl;
    return 0;
}