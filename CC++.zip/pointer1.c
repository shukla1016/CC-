#include<stdio.h>
void main()
{
    int *p=NULL;
    printf("The value of pointer is = %ls",p);
}