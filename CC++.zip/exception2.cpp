#include <iostream>
using namespace std;

void exceptionFunction()
{
    try{
        throw 0;
    }catch(int i)
    {
        cout << "\n In Function: wrong Input" << i << endl;
    }
}

int main()
{
    int var = 0;

    cout << "Simple C++ prog." << endl;
    try{
        exceptionFunction();
    }catch(int ex)
    {
        cout << "\n In Function: wrong Input" << ex; 
    }
    return 0;
}