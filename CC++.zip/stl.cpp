#include <iostream>
#include <vector>
using namespace std;

int main()
{
    vector<int>a;
    int i;
    for(i = 0;i < 5;i++)
    {
        a.push_back(i);
    }
    cout << "Size : " << a.size() << endl;
    cout << "Capacity : " << a.capacity() << endl;
    cout << "Max Size : " << a.max_size() << endl;
    for(auto j = a.begin(); j<a.end();j++)
    cout << *j;
    cout << endl;
    a.resize(4);
    for(auto j = a.begin(); j<a.end();j++)
    cout << *j;
    cout << endl;
    cout << "Size : " << a.size() << endl;
    cout << "Capacity : " << a.capacity() << endl;

    if (a.empty() == false)
        cout << "Vector is not empty." << endl;
    else
    {
        cout << "Vector is empty." << endl;
    }
}