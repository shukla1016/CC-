#include <iostream>
using namespace std;

class Line
{
    public:
        int l;
        int b;
        Line()
        {
            l = 3;
            b = 6;
            int res = area(l,b);
            cout << "Res = " << res << endl;
        }
        Line(int a)
        {
            l = b = a;
            int res = area(l,b);
            cout << "Res = " << res << endl;
        }
        Line(int a, int b)
        {
            l = a;
            this->b = b;
            int res = area(l,b);
            cout << "Res = " << res << endl;
        }
        int area (int a, int b)
        {
            return a*b;
        }
};
int main()
{
    Line s1;
    Line s2(8);
    Line s3(2,6);
}