#include <iostream>
using namespace std;

bool canVote(int x)
{
    if (x < 18)
    {
    cout << "Not allowed" << endl;
    x  = 18;
    return false;
    }
    else
    {
    cout << "Allowed" << endl;
    x = 18;
    return true;
    }
}
int main()
{
    int age;
    cout << "Enter Age"<<endl;
    cin >> age;
    canVote(age);
    cout << "call by value " << age << endl;
    return 0;
}