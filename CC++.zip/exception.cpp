#include <iostream>
using namespace std;

int main()
{
    int num = 10;
    int den = 0;
    char c = 'a';
    float f = 1.0f;
    double d = 2.0;
    try
    {
        if(num)
        {
            cout << "num" << endl;
        }
        else
        throw(num);
    }
    catch(char a)
    {
        cout << "Char" << endl;
    }
    catch(double d)
    {
        cout << "Double" << endl;
    }
    catch(float f)
    {
        cout << "Float" << endl;
    }
    catch(int num)
    {
        cout << "Int" << endl;
    }
    cout << "Hello" << endl;
    return 0;
}