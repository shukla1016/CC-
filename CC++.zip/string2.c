#include<stdio.h>
#include<string.h>
void main()
{
    char name[20];
    printf("Enter Name");
    scanf("%s", name);
    printf("Your name is %s.",name);
}