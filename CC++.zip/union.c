#include<stdio.h>
union test
{
    int data;
    char c[32];
    float num;
}u;
struct test1
{
    int data;
    char c[32];
    float num;
}s;
void main()
{
    printf("size of union = %lu\n",sizeof(u));
    printf("size of structure = %lu",sizeof(s));
}