#include<iostream>
using namespace std;
namespace addition{
    namespace subtraction{
            int operation(int x, int y)
            {
                return x-y;
            }
        }
    int operation()
    {
        int x,y;
        cin >> x >> y;
        cout << "Subtraction = " << subtraction::operation(x,y)<<endl;
        return x+y;
    }
}
namespace multipication{
    int operation(){
        int x,y;
        cin >> x >> y;
        return x*y;}
}
int main()
{
    cout << addition::operation() <<" = Addition "<< '\n';
    // cout << "subtraction = " << subtraction::operation() << '\n';
    cout << "multipication = " << multipication::operation() << '\n';
    // cout << "subtraction = " << sub::operation() << '\n';
    return 0;
}