#include<stdio.h>
int main()
{
    FILE *fp;
    char c;
    fp = fopen("/home/parth/cprog/test.txt","r");
    if (fp==NULL)
    {
        printf("\nFile does not exist.");
    }
    while(1)
    {
        c=fgetc(fp);
        if(c==EOF)
        {
            break;
        }
        printf("%c",c);
    }
    fclose(fp);
    return 0;
}