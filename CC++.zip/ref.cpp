#include <iostream>
using namespace std;

int main()
{
    int i;
    double d;
    int &r = i;
    double &s = d;
    i = 5;
    d = 5.5;
    cout << i << endl << "Refrence = " << r << endl << d << endl << "Refrence = " << s << endl;
    return 0;
}