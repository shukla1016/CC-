#include<stdio.h>
#include<stdlib.h>

struct Node{
    int data;
    struct Node *next;
}*head=NULL,*last=NULL;
void reverse()
{
    struct Node *p=NULL;
    struct Node *q=head;
    struct Node *r=NULL;
    while(q!=NULL)
    {
        r = q->next;
        q->next = p;
        p = q;
        q = r;
    }
    head = p;
}

void insertLast(int data)
{
    struct Node *temp= (struct Node*)malloc(sizeof(struct Node));
    temp->data = data;
    temp->next = NULL;
    if (head == NULL)
    {
        head = temp;
        last = temp;
    }
    else
    {
        last->next=temp;
        last=temp;
    }
}

void insertMiddle(int data, int pos)
{
    struct Node *temp1 = head;
    struct Node *temp= (struct Node*)malloc(sizeof(struct Node));
    temp->data = data;
    temp->next = NULL;
    for(int i=0;i<pos-2;i++)
    {
        temp1 = temp1->next;
    }
    temp->next = temp1->next;
    temp1->next = temp;
}

void deleteMiddle(int pos)
{
    struct Node *temp1 = head;
    for(int i=0;i<pos-2;i++)
    {
        temp1 = temp1->next;
    }
    struct Node *temp2;
    temp2 = temp1->next;
    temp1->next = temp2->next;
    free(temp2);
}

void sortInsert(int data)
{
    struct Node *temp= (struct Node*)malloc(sizeof(struct Node));
    temp->data = data;
    temp->next = NULL;
    if(head == NULL || data < head->data)
    {
        temp->next = head;
        head = temp;
    }
    else
    {
    struct Node *p = head;
    while(p->next != NULL && p->next->data<=data)
    {
        p=p->next;
    }
    temp->next = p->next;
    p->next = temp;
    }
}

void isLoop()
{
    int f=0;
    struct Node *p=head,*q=head;
    while(p&&q&&p->next)
    {
        p=p->next->next;
        q=q->next;
        if(p==q)
        {
            printf("LOOP");
            f=1;
            break;
        }
    }
    if(f==0)
    printf("NO LOOP");
}

void print()
{
    struct Node *temp = head;
    while(temp != NULL)
    {
        if(temp->next==NULL)
        printf("%d",temp->data);
        else
        printf("%d->",temp->data);
        temp=temp->next;
    }
}

void main()
{
    insertLast(21);
    insertLast(25);
    insertLast(211);
    insertLast(2);
    insertLast(2555);
    print();
    printf("\n");
    insertMiddle(50,2);
    print();
    printf("\n");
    deleteMiddle(2);
    print();
    printf("\n");
    isLoop();
    // printf("\n %d",r);
    // reverse();
    // print();
    printf("\n");
    last->next=head;
    isLoop();
    // printf("\n %d",r);
}