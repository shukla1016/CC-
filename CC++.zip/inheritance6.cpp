#include <iostream>
using namespace std;

class World{
    public:
        World()
        {
            cout << "This is World." << endl; 
        }
};

class Continent : public World{
    public:
        Continent()
        {
            cout << "This is Continent." << endl;
        }
};

class Country : public World{
    public:
        Country()
        {
            cout << "This is Country." << endl;
        }
};

class India : public Country, public Continent{
    public:
        India()
        {
            cout << "This is India." << endl;
        }
};

int main()
{
    India india;
}