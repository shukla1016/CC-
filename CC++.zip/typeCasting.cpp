#include <iostream>
using namespace std;

int main()
{
    int a = 10;
    float b = (float)a;
    double d = a;
    cout << a << "==" << b << "==" << d << "==" << endl;

    float a1 = 10.213;
    int b1 = a1;
    double d1 = a1;
    cout << a1 << "==" << b1 << "==" << d1 << "==" << endl;

    double a2 = 105.643;
    float b2 = a2;
    int d2 = a2;
    cout << a2 << "==" << b2 << "==" << d2 << "==" << endl;
    return 0;
}