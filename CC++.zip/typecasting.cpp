class B{};
class D :public B{};
void f(B* pb, D* pd)
{
    D* pd2 = static_cast<D*>(pb);
    B* pb2 = static_cast<B*>(pd);
}

int main()
{
    B *b;
    D *d;
    f(b,d);
    return 0;

}