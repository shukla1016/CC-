#include <stdio.h>
#include <stdlib.h>
struct queue
{
    int front, rear, size, capacity;
    int *arr;
}q;
void insertQueue(int data)
{
    if(q.rear<q.capacity)
    {
        q.rear++;
        q.arr[q.rear] = data;
        q.size++;
    }
    else{
        printf("Overflow");
        return;
    }
}

void isEmpty()
{
    if(q.size == 0)
    {
        printf("EMPTY!!");
    }
    else
    {
        printf("NOT EMPTY!!");
    }
}

void peek()
{
    if(q.size == 0)
    {
        printf("No-one is here !");
    }
    else{
        printf("%d",q.arr[q.front]);
    }
}

void print()
{
    for(int i = q.front;i<=q.rear;i++)
    {
        printf(" %d ",q.arr[i]);
    }
}

void deleteQueue()
{
    
}

void main ()
{
    q.capacity = 10;
    q.front = 0;
    q.size = 0;
    q.rear = -1;
    q.arr = (int*)malloc(q.capacity*sizeof(int));
    isEmpty();
    printf("\n");
    peek();
    printf("\n");
    insertQueue(20);
    insertQueue(25);
    insertQueue(2);
    insertQueue(29);
    insertQueue(30);
    print();
    printf("\n");
    isEmpty();
    printf("\n");
    peek();
    // deleteQueue();
    printf("\n");
    print();
}