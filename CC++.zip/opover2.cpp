#include <iostream>
using namespace std;

class OverLoad{
    private:
    int a;
    int b;

    public:
    OverLoad() : a(0), b(0) {}

    void in ()
    {
        cout << "Enter 1st Number";
        cin >> a;
        cout << "Enter 2nd Number";
        cin >> b;
    }
    void operator--()
    {
        a = --a;
        b = --b;
    }

    void out()
    {
        cout << "The decremented elements of the object are " << a << " , " << b << endl;
    }
};

int main(){
    OverLoad obj;
    obj.in();
    --obj;
    obj.out();
}