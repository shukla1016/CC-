#include <iostream>
using namespace std;

class Base{
    public:
        void print()
        {
            cout << "Hello I'm in base class. (Example of Multilevel Inheritance.)" << endl; 
        }
};

class Derived1 : public Base{};
class Derived2 : public Derived1{};

int main()
{
    Derived2 x;
    x.print();
}