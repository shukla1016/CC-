#include<stdio.h>
#define PI 3.14
void main()
{
    printf("AREA OF CIRCLE IS %f",(PI*6*6));
} 