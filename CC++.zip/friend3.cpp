#include <iostream>
using namespace std;
class B;
class A {
    private : int meterA;
    friend B;
    public :
        A() : meterA(110){}
};

class B {
    private : int meterB;
    A a;
    friend int add(B, int n);
    public :
        B() : meterB(12){}
        int v = a.meterA;
};

int add(B b, int meterA)
{
    int a1 = meterA + b.meterB;
    return a1;
}

int main()
{
    B b;
    int a1 = add(b,b.v);
    cout << a1 << endl;
    return 0;
}