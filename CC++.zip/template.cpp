#include <iostream>
using namespace std;

template <class T>
T sum(T a, T b)
{
    T c = a+b;
    return c;    
}
 
int main ()
{
    int res = sum<int>(4,5);
    double res1 = sum<double>(2.1,3.6);
    cout << res << endl << res1 << endl;
    return 0;
}