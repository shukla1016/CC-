#include<iostream>
using namespace std;

int main()
{
    int a=9,b=92;
    if(a+b>10)
    cout<<"yes"<<a+b<<"is greater than 10";
    return 0;
}