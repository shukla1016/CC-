#include <iostream>
using namespace std;

class Car{
    public:
    void Car1()
    {
        cout << "I'm Car" << endl;
    }
    virtual void start() = 0;
    virtual void stop() = 0;
    virtual ~Car ()=0;
    
};

Car::~Car()
{
    cout << "I'm destructor of Car" << endl;
}

class Innova : public Car{
    public:
    void start()
    {
        cout << "Welcome to INNOVA." << endl;
    }
    void stop()
    {
        cout << "Please get out from INNOVA." << endl;
    }
    ~Innova()
    {
        cout << "I'm destructor of INNOVA" << endl;
    }
};

class Swift : public Car{
    public:
    void start()
    {
        cout << "Welcome to SWIFT." << endl;
    }
    void stop()
    {
        cout << "Please get out from SWIFT." << endl;
    }
    ~Swift()
    {
        cout << "I'm destructor of SWIFT" << endl;
    }
};

int main()
{
    Car *p = new Innova();
    p->start();
    p->stop();
    delete p;
    p = new Swift();
    p->start();
    p->stop();
    delete p;
}