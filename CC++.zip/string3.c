#include<stdio.h>
#include<string.h>
void main()
{
    char name[20];
    printf("Enter Name\n");
    fgets(name,sizeof(name),stdin);
    printf("Name : ");
    puts(name);
}