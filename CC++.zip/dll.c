#include<stdio.h>
#include<stdlib.h>

struct Node{
    int data;
    struct Node *next;
    struct Node *prev;
}*head=NULL,*last=NULL;
void insertLast(int data)
{
    struct Node *temp= (struct Node*)malloc(sizeof(struct Node));
    temp->data = data;
    temp->next = NULL;
    temp->prev = NULL;
    if (head == NULL)
    {
        head = temp;
        last = temp;
    }
    else
    {
        last->next=temp;
        temp->prev=last;
        last=temp;
    }
}
void delete(int pos)
{
    struct Node *temp = head;
    for(int i = 0;i < pos-1;i++)
    temp = temp->next;
    temp->prev->next = temp->next;
    temp->next->prev = temp->prev;
    free(temp);
}
void deleteData(int data)
{
    int c = 1;
    int f = 0;
    struct Node *temp = head;
    while(temp!=NULL)
    {
        if(temp->data==data)
        {
            f=1;
            delete(c);
            break;
        }
        c++;
        temp=temp->next;
    }
    if(f==1)
    {
        deleteData(data);
    }
}
void print()
{
    struct Node *temp = head;
    while(temp != NULL)
    {
        if(temp->next==NULL)
        printf("%d",temp->data);
        else
        printf("%d<->",temp->data);
        temp=temp->next;
    }
}
void main()
{
    insertLast(20);
    insertLast(25);
    insertLast(30);
    insertLast(30);
    insertLast(30);
    insertLast(30);
    insertLast(2);
    insertLast(29);
    print();
    // printf("\n");
    // delete(3);
    // delete(4);
    // delete(5);
    // delete(6);
    // print();
    printf("\n");
    deleteData(30);
    print();
    printf("\n");
}