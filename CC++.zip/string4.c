#include<stdio.h>
#include<string.h>
void display(char p[]);
void main()
{
    char name[20];
    printf("Enter Name\n");
    fgets(name,sizeof(name),stdin);
    display(name);
}
void display(char p[])
{
    printf("Output : ");
    puts(p);
}
