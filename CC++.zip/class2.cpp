#include<iostream>
using namespace std;
class Rectangle{
    int l;
    int br;
    int area (int a, int b){return a*b;}
    public:
    Rectangle(int a, int b)
    {
        l = a;
        br = b;
        int res = area(l,br);
        cout << "Res = " << res << endl;
    }
};
int main()
{
    Rectangle r(30,70);
}