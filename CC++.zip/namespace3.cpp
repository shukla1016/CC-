#include<iostream>
using namespace std;
namespace first{
    int x = 5;
    int y = 20;
}
namespace second{
    double x = 1.55;
    double y = 2.55;
}
int main()
{
    {
        using namespace first;
        cout << x << '\n';
        cout << y << '\n';
    }
    {
        using namespace second;
        cout << x << '\n';
        cout << y << '\n';
    }
    return 0;
}