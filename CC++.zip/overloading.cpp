#include<iostream>
using namespace std;

void display(int)
{
    cout << "INT" << endl;
}

void display(float)
{
    cout << "FLOAT" << endl;
}

int main()
{
    display(1.0f);
    display(1);
}