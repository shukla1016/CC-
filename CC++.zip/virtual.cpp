#include <iostream>
using namespace std;

class Base{
    public:
    Base()
    {
        cout << "I'm at BASE." << endl;
    }
    void display()
    {
        cout << "Welcome To BASE." << endl;
    }
    void display1()
    {
        // cout << "Welcome To BASE." << endl;
    }
    virtual ~Base()
    {
        cout << "I'm destructor of BASE" << endl;
    }
};

class Derived : public Base{
    public:
    Derived()
    {
        cout << "I'm at Derived1." << endl;
    }
    void display()
    {
        cout << "Welcome to DERIVED." << endl;
    }
    void display1()
    {
        // cout << "Welcome to DERIVED." << endl;
    }
    virtual ~Derived()
    {
        cout << "I'm destructor of DERIVED 1" << endl;
    }
};

class Derived2 : public Derived{    
    public:
    Derived2()
    {
        cout << "I'm at Derived2." << endl;
    }
    void display()
    {
        cout << "Welcome to DERIVED." << endl;
    }
    void display1()
    {
        // cout << "Welcome to DERIVED." << endl;
    }
    ~Derived2()
    {
        cout << "I'm destructor of DERIVED 2" << endl;
    }
};

int main()
{
    Base *p = new Derived2();
    p->display();
    p->display1();
    delete p;
}