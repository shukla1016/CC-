#include <iostream>
using namespace std;

class Base{
    public:
        int salary = 1000;
};

class Derived : public Base{
    public: 
        int bonus = 500;
        void sum()
        {
            cout << "The total salary is " << (salary + bonus) << endl; 
        }
};

int main()
{
    Derived x;
    x.sum();
}