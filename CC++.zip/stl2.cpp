#include <iostream>
#include <vector>
using namespace std;

int main()
{
    vector<int>a;
    int i;
    for(i = 0;i < 5;i++)
    {
        a.push_back(i);
    }
    cout << "Size : " << a.size() << endl;
    cout << "Capacity : " << a.capacity() << endl;
    cout << "Max Size : " << a.max_size() << endl;
    cout << "a[2] " << a[2] << endl;
    cout << "a.at(4) = "<< a.at(4) << endl;
    cout << "a.front = "<< a.front() << endl;
    cout << "a.back = "<< a.back() << endl;
    for(auto j = a.begin(); j<a.end();j++)
    cout << *j;
    cout << endl;
    a.resize(4);
    for(auto j = a.begin(); j<a.end();j++)
    cout << *j;
    cout << endl;
    cout << "Size : " << a.size() << endl;
    cout << "Capacity : " << a.capacity() << endl;

    int *pos = a.data();
    cout << "First Element : " << *pos << endl;

    if (a.empty() == false)
        cout << "Vector is not empty." << endl;
    else
    {
        cout << "Vector is empty." << endl;
    }
}