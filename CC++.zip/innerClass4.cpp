class A{
    private:
    class B {};
    B *z;
    class C : private B {
        private:
        B y;
        C *x;
    };
};

int main()
{}