#include<stdio.h>
int *fun()
{
    int y=10;
    return &y;
}
void main()
{
    int *p = fun();
    printf("%d",*p);
}