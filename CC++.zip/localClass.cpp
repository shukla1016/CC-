#include <iostream>
using namespace std;

void fun ()
{
    class local{
        public:
        void method()
        {
            cout << "I'm inside Local" << endl;
        }
    };
    local t;
    t.method();
}

int main()
{
    fun();
}