#include<stdio.h>
#include<string.h>
void main()
{
    char name[20];
    printf("Enter Name\n");
    fgets(name,sizeof(name),stdin);
    printf("Name : ");
    strupr(name);
    puts(name);
    strrev(name); 
    printf("\n");
    puts(strrev(name)); 
}