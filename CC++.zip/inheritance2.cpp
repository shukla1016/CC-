#include <iostream>
using namespace std;

class Base{
    public:
        int salary = 1000;
};

class Derived1 : public Base{
    public: 
        int bonus = 500;
        int finalSalary = salary + bonus;
};

class Derived2 : public Derived1{
    public: 
        void sum()
        {
            cout << "The total salary is " << salary << endl; 
        }
};

class Derived3 : public Derived2{
    public: 
        void sum()
        {
            cout << "The total salary is " << salary << endl; 
        }
};

int main()
{
    Derived3 x;
    cout << x.salary;
    x.sum();
}