#include<stdio.h>
#include<string.h>
void main()
{
    char ch[] = "123456789";
    char ch1[] = "abcdefghijk";
    strcat(ch,ch1);
    puts(ch1);
    puts(ch);
   
}