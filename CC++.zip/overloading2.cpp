#include<iostream>
using namespace std;

void multiply(int a, int b)
{
    cout << "Multipy(I) = " << (a*b) << endl;
}

// int multiply(int a, int b)
// {
//     cout << "Multipy(IR) = " << (a*b) << endl;
//     return a*b;
// }

void multiply(double a, double b)
{
    cout << "Multipy(D) = " << (a*b) << endl;
}

void multiply(int a, double b)
{
    cout << "Multipy(I,D) = " << (a*b) << endl;
}

void multiply(double a, int b)
{
    cout << "Multipy(D,I) = " << (a*b) << endl;
}

int main()
{
    multiply(10,20);
    multiply(10.0,20.0);
    multiply(10,20.0);
    multiply(10.0,20);
}