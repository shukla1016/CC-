#include<iostream>
using namespace std;
namespace addition{
    int operation(){
        int x,y;
        cin >> x >> y;
        return x+y;}
}
namespace subtraction{
    int operation(int x, int y){
        return x-y;}
}
namespace sub{
    double operation(){
        int x,y;
        cin >> x >> y;
        return subtraction::operation(x,y);}
}
namespace multipication{
    int operation(){
        int x,y;
        cin >> x >> y;
        return x*y;}
}
int main()
{
    cout << "Addition = " << addition::operation() << '\n';
    // cout << "subtraction = " << subtraction::operation() << '\n';
    cout << "multipication = " << multipication::operation() << '\n';
    cout << "subtraction = " << sub::operation() << '\n';
    return 0;
}