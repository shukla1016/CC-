#include<stdio.h>
struct address
{
    char city[20];
    int pin;
    char phone[14];
};
struct employee
{
    char name[20];
    struct address add;
};
void display();
void main()
{
    struct employee e;
    printf("Enter emp info");
    scanf("%d %s %s %s",&e.add.pin,e.add.city,e.add.phone,e.name);
    display(e);
}
void display(struct employee e)
{
    printf("printing details");
    printf("%d %s %s %s",e.add.pin,e.add.city,e.add.phone,e.name);
}