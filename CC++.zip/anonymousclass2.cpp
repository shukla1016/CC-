#include <iostream>
using namespace std;

typedef class{
    int value;
    public:
    void setData(int i)
    {
        this->value = i;
    }
    void printValue()
    {
        cout << "value = " << this->value << endl;
    }
}
myclass;

typedef class : public myclass
{
    public:
    void fun(){
        setData(4153);
        printValue();
    }
}A;

int main()
{
    myclass obj1, obj2;
    obj1.setData(10);
    obj1.printValue();
    obj2.setData(130);
    obj2.printValue();
    A r;
    r.fun();
}