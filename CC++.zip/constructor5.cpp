#include <iostream>
using namespace std;

class Line
{   int size;
    int l;
    int b;
    public:
        Line()
        {
            size = 30;
            l = b = 20;
        }
        void modify(int a, int b)
        {
            l = a;
            this->b = b;
        }
        void print() const 
        {
            cout << l << " --- " << b << endl;
        }
};
int main()
{
    const Line s;
    Line s1;
    // s.modify(1,2);
    s1.modify(80,90);
    s.print();
    s1.print();
}