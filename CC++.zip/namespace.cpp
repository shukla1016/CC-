#include<iostream>
using namespace std;
namespace first{
    int x = 5;
    int y = 20;
}
namespace second{
    double x = 1.55;
    double y = 2.55;
}
int main()
{
    using first :: x;
    using second :: y;
    cout << x << endl;
    cout << y << endl;
    return 0;
}