#include <iostream>
using namespace std;

int x;
void fun()
{
    class Test1{
        public:
        Test1(){cout << "Test1::Test()" << endl;}
        void test3()
        {
            cout << "TEST 3" << endl;
        }
    };
    class Test2: public Test1{
        public:
        void method()
        {
            cout << "x = " << x << endl;
            // Test1 t1;
            // t1.test3();
            test3();
        }
    };
    Test2 t;
    t.method();
} 

int main()
{
    fun();
    return 0;
}