#include<stdio.h>
int main()
{
    FILE *fp;
    char buff[255];
    fp = fopen("/home/parth/cprog/test.txt","r");
    while(fscanf(fp,"%s",buff)!=EOF)
    {
        printf("%s \n",buff);
    }
    fclose(fp);
    return 0;
}