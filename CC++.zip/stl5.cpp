#include<iostream>
#include<vector>
using namespace std;

int main()
{
    vector<int> num{1,2,3,4,5};
    vector<int >::iterator iter;
    iter = num.begin();
    cout << "num[0] = " << *iter;
    return 0;
}